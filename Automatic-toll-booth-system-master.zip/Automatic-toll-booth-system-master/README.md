# Automatic-toll-booth-system
A automated system for recognising vehicles number plate and deducting the required amount from their cloud based wallet.
Required hardwares: 
-> Arduino UNO
-> Servo Motor
-> Vehicle Number Plates
